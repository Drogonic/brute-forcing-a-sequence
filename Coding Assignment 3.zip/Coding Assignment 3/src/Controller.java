public class Controller {
    public static int[] masterList = {1, 1, 2, 23, 133, 796, 4829, 29189, 176458, 1066867, 6450137, 38996684, 235769041, 1425429721, 28032690, 563529791, 1476348285, 1833717308, -416270187, 1718152701};


    public static void main(String[] args) {

        String results = null;

            for (int x = -10; x <= 10; x++) {
                for (int y = -10; y <= 10; y++) {
                    for (int z = -10; z <= 10; z++) {
                        int[] testList = new int[20];
                        for (int n = 0; n <= 19; n++) {
                            testList[n] = sequenceGen(n, x, y, z);
                            //triggers once we have created a full sequence
                            if (n == 19) {
                                //just to show the various sequences being created
                                System.out.printf("X:\t %5d \n Y:\t %5d \n Z:\t %5d \n", x, y, z);
                                for (int p = 0; p <= 19; p++) {

                                    if (p == 19) {
                                        System.out.print(testList[p] + "\n");
                                    } else {
                                        System.out.print(testList[p] + ",");
                                    }
                                }
                                results = check(testList, x, y, z);
                                if (results.equals("jackpot")) {
                                    System.out.printf("\nX:\t %5d \n Y:\t %5d \n Z:\t %5d \n", x, y, z);
                                    System.out.println("CREATION LIST:");
                                    for (int p = 0; p <= 19; p++) {

                                        if (p == 19) {
                                            System.out.print(testList[p] + "\n");
                                        } else {
                                            System.out.print(testList[p] + ",");
                                        }
                                    }
                                    x=100;
                                    y=100;
                                    z=100;
                                }

                            }
                        }
                    }


                    }
                }


        System.out.println("MASTER LIST:");
        for (int p = 0; p <= 19; p++) {

            if (p == 19) {
                System.out.print(masterList[p] + "\n");
            } else {
                System.out.print(masterList[p] + ",");
            }
        }
    }


                public static String check ( int[] list, int x, int y, int z){

                    String result = "jackpot";
                    for (int w = 0; w <= 19; w++) {
                        //simple check where I just count the number of matching
                        if (list[w] != masterList[w]) {
                            result="no";
                        }


                    }
                    return result;
                }


                public static int sequenceGen ( int n, int x, int y, int z){
                    if (n == 0) {
                        return 1;
                    } else if (n == 1) {
                        return 1;
                    } else if (n == 2) {
                        return 2;
                    } else {
                        return x * sequenceGen(n - 1, x, y, z) + y * sequenceGen(n - 2, x, y, z) + z * sequenceGen(n - 3, x, y, z);
                    }
                }

            }




